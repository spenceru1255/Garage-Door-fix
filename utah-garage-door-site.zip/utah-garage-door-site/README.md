# Utah County Garage Door Website

Static SEO starter site focused on garage door repair, broken springs, openers, cables, off-track doors, and installation.

## Replace before launch
1. Edit `assets/config.js` with the real business name, phone, email, and domain.
2. Replace `https://www.example.com` in all HTML, robots.txt, and sitemap.xml.
3. Connect the lead form to a real CRM/form endpoint.
4. Add only real addresses, licensing numbers, warranties, reviews, response times, and years in business.
5. Add original project/technician photos and useful alt text.
6. Add privacy/terms pages.
7. Add accurate LocalBusiness schema after real business location/details are known.
8. Submit sitemap to Google Search Console and validate structured data.

## Pages included
- Homepage
- 6 service pages
- 5 city pages
- robots.txt + sitemap.xml

City pages are deliberately written with different local intros, while service pages focus on distinct customer problems. Expand them over time with real jobs, original photos, FAQs, pricing context, and neighborhood-level experience rather than duplicating text.
