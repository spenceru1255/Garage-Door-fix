window.SITE_CONFIG = {
  businessName: "YOUR GARAGE DOOR BUSINESS",
  phoneDisplay: "(801) 555-0147",
  phoneTel: "+18015550147",
  email: "service@example.com",
  domain: "https://www.example.com",
  serviceArea: "Utah County, Utah"
};
